function crearusuario(){

        //  alert("El entro a funcion");


        

         //document.getElementById("main_container").setAttribute("style", "background-color:#F00;");
         //document.getElementById("main_container").setAttribute("style", "pointer-events: none;");
         //$('#main_container').click(false);
         //$("#main_container").children().attr("disabled","disabled");


   
       var nombre=document.getElementById("nombre").value;
	
	   var paterno=document.getElementById("paterno").value;
	
	   var materno=document.getElementById("materno").value;

       var genero=document.getElementById("genero").value;
    
       var fecha_nacimiento=document.getElementById("fecha_nacimiento").value;

       var edad_califica=document.getElementById("edad_califica").value;


	
       var user=document.getElementById("user").value;
       var pass1=document.getElementById("pass1").value;
       var pass2=document.getElementById("pass2").value;

       var area=document.getElementById("sel").value;
       var correo=document.getElementById("correo").value;
       var correo2=document.getElementById("correo2").value;
	
	   	var tmptxt=document.getElementById("tmptxt"). value;
		var tmptxt2=document.getElementById("tmptxt2"). value;
        var error=0;
        var error_string="";


	
       
        if (nombre == 0)
        {
            error_string+="<p>El campo nombre no puede estar vacío</p>";
            error++;
            
        } //nombre
	
	
	    if (paterno == 0)
        {
            error_string+="<p>El campo paterno no puede estar vacío</p>";
            error++;
            
        } //paterno
	
	
	    if (materno == 0)
        {
           error_string+="<p>El campo materno no puede estar vacío</p>";
        
            error++;
            
        } //materno

        if (genero == 0)
        {
            error_string+="<p>Selecciona una opción en el campo género</p>";
            error++;
            
        } //genero


        if (edad_califica == 0 ||edad_califica == '0')
        {
            error_string+="<p>"+"Fecha de nacimiento fuera del rango permitido"+"</p>";
            
            error++;
            
        } //materno
        
    
        if (user == 0)
        //alert("Hola!!");
        {
            error_string+="<p>"+"El campo usuario no debe estar vacío"+"</p>";
            //$("#user").focus();
            error++;
            
        }//user
        
        if (pass1 == 0)
        //alert("Hola!!");
        {
            error_string+="<p>"+"El campo contraseña no debe estar vacío"+"</p>";
            //$("#pass1").focus();
            error++;
            
        }//pass1

        if (pass2 == 0)
        //alert("Hola!!");
        {
            error_string+="<p>"+"El campo repetir contraseña no debe estar vacío"+"</p>";
            //$("#pass2").focus();
            error++;
            
        }//pass2
        
        if (pass1 != pass2)
        //alert ("Hola");
        {
            error_string+="<p>"+"La contraseña no coincide"+"</p>";
            error++;
            
        }// valida contraseña
        
        
        if ((area == undefined)||(area == 0))
        {
            alert("Seleccione un tipo de Concurso");
            //$("#sel").focus();
            error++;
            
        }//sel
        
        
        if (correo == 0)
        {
            error_string+="<p>"+"El campo correo no debe estar vacío"+"</p>";
            error++;
            //$("#correo").focus();
            
        }//correo
        
        if (/^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,4})$/.test(correo)){
            //alert("La dirección de email es correcta.");
        } else {
            error_string+="<p>"+"La dirección de email es incorrecta."+"</p>";
            error++;
            

        }
        

        if (correo2 == 0)
        {
            error_string+="<p>"+"El campo repetir correo no debe estar vacío"+"</p>";
            //$("#correo2").focus();
            error++;
            
        }//correo
        
        if (correo != correo2)
        //alert ("Hola");
        {
            error_string+="<p>"+"El correo electrónico no coincide"+"</p>";
            error++;
            
        }
        
        if(tmptxt==0)
		{
		   error_string+="<p>"+"El campo del CAPCHA no debe estar vacío"+"</p>";
            //$("#tmptxt").focus();
            error++;
            
		}
	
        if ( tmptxt == tmptxt2)
			{
				error_string+="<p>"+" El CAPCHA no coincide"+"</p>";
                 error++;
            
				
			}

        var textloader='<div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div>';
        document.getElementById("errormsg").innerHTML=textloader;

        document.getElementById("main_container").setAttribute("style", "pointer-events: none;");

        

        

        //return false;


        

        //alert(edad_califica+" * ");

        if(error>0){
            document.getElementById("btn_crearusuario").disabled=false;
            document.getElementById("btn_crearusuario").innerHTML="Crear cuenta de usuario";
            document.getElementById("errormsg").innerHTML="<div class='alert alert-warning' >"+error_string+"</div>";
            document.getElementById("main_container").setAttribute("style", "pointer-events: auto;");
            return false;

        }
        
               
    var datos="action=insert"+"&nombre="+nombre+"&paterno="+paterno+"&materno="+materno+"&genero="+genero+"&fecha_nacimiento="+fecha_nacimiento+"&user="+user+"&pass1="+pass1+"&pass2="+pass2+"&area="+area+"&concurso="+area+"&correo="+correo;
       
       
	var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var resultado=this.responseText;
                //alert(resultado);

                if(resultado=='1'||resultado=='2'||resultado=='12'||resultado==1||resultado==2||resultado==12){
                    var texto="";
                    
                    if(resultado=='1'||resultado=='12'||resultado==1||resultado==12)texto+="<div class='alert alert-warning' >El nombre de usuario ya está registrado.</div>";
                    if(resultado=='2'||resultado=='12'||resultado==2||resultado==12)texto+="<div class='alert alert-warning' >El correo ya está registrado.</div>";

                    document.getElementById("errormsg").innerHTML =texto;
                    document.getElementById("btn_crearusuario").disabled=false;
                    document.getElementById("btn_crearusuario").innerHTML="Crear cuenta de usuario";
                    document.getElementById("main_container").setAttribute("style", "pointer-events: auto;");
                    //return false;
                    
                }else{
                    document.getElementById("main_container").innerHTML = resultado;
                     document.getElementById("main_container").setAttribute("style", "pointer-events: auto;");

                }
                


            }
        };
	
	xmlhttp.open("POST", "usuarios.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8"); 
    xmlhttp.send(datos);
/**/
}

function guardarparticipante(){

         errors=0;
         error_string="";
   
      var nombre=document.getElementById("nombre").value;
    
       var paterno=document.getElementById("paterno").value;
    
       var materno=document.getElementById("materno").value;



       var genero=document.getElementById("genero").value;

      
    
       var fecha_nacimiento=document.getElementById("fecha_nacimiento").value;

       

       var sobrenombre=document.getElementById("sobrenombre").value;
       if(sobrenombre==""){
        errors++;
        error_string+="<p>El campo sobrenombre no puede estar vacío</p>";

       }


    
       var idusuario=document.getElementById("idusuario").value;
       var area=document.getElementById("area").value;
       var distrito=document.getElementById("distrito").value;
       
       

       var lugar_nacimiento=document.getElementById("lugar_nacimiento").value;
       if(lugar_nacimiento==""){
        errors++;
        error_string+="<p>El campo lugar de nacimiento no puede estar vacío</p>";

       }
       var lugar_residencia=document.getElementById("lugar_residencia").value;
       if(lugar_residencia==""){
        errors++;
        error_string+="<p>El campo lugar de residencia no puede estar vacío</p>";

       }

       var resido_cdmx=+document.getElementById("resido_cdmx").checked;
       var soyoriundo=+document.getElementById("soyoriundo").checked;
       var soyoriginario=+document.getElementById("soyoriginario").checked;
       var suma=resido_cdmx+soyoriundo+soyoriginario;
       if(suma==0){
        errors++;
        error_string+="<p>Debes seleccionar al menos uno de los checkbox de Resido en la Ciudad de México, o Soy oriundo de la Ciudad de México o Soy hija/o de madre o padre originario de la Ciudad de México</p>";

       }

       var tel1=document.getElementById("tel1").value;
       if(isNaN(tel1)||tel1==""){
        errors++;
        error_string+="<p>El teléfono local debe contener números únicamente</p>";

       }

       var tel2=document.getElementById("tel2").value;
       if(isNaN(tel2)||tel2==""){
        errors++;
        error_string+="<p>El teléfono celular debe contener números únicamente</p>";

       }


       var correo=document.getElementById("correo").value;


       var correo_tutor=document.getElementById("correo_tutor").value;
       var edad=document.getElementById("edad").value;
       //alert(correo_tutor);

       if(edad<=17){

        if(correo_tutor==""){
             errors++;
             error_string+="<p>"+"La dirección de correo electrónico no puede estar vacía"+"</p>";
        }

        if (/^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,4})$/.test(correo_tutor)){
            //alert("La dirección de email es correcta.");
        }else{
            error_string+="<p>"+"La dirección de correo electrónico es incorrecta."+"</p>";
            errors++;
            

        }


       }

      

        if(errors>0){

           // alert(document.getElementById('div_errors').innerHTML);
            //document.getElementById("div_errors").innerHTML="xxxxxxxxx";
            document.getElementById('div_errors').innerHTML='<div class="alert alert-warning">'+error_string+'</div>';
            document.getElementById("btn_guardar").disabled=false;
            return false;


        }

       
        
    
       
        

    
        
               
    var datos="action=insert"+"&nombre="+nombre+"&paterno="+paterno+"&materno="+materno+"&sobrenombre="+sobrenombre+"&genero="+genero;
    datos+="&fecha_nacimiento="+fecha_nacimiento+"&idusuario="+idusuario+"&area="+area;
    datos+="&lugar_nacimiento="+lugar_nacimiento+"&lugar_residencia="+lugar_residencia+"&resido_cdmx="+resido_cdmx;
    datos+="&soyoriundo="+soyoriundo+"&soyoriginario="+soyoriginario+"&tel1="+tel1+"&tel2="+tel2+"&correo_tutor="+correo_tutor+"&correo="+correo;
    datos+="&distrito="+distrito+"&enlace=main";
    
    //document.getElementById("menu1").innerHTML = datos;
    //alert(datos);
    var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("menu1").innerHTML = this.responseText;
                document.getElementById('div_errors').innerHTML='';
                



            }
        };
    
    xmlhttp.open("POST", "guardarparticipante.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8"); 
    xmlhttp.send(datos);

}


function fnsiguiente(){

         errors=0;
         error_string="";
   
      var nombre=document.getElementById("nombre").value;
    
       var paterno=document.getElementById("paterno").value;
    
       var materno=document.getElementById("materno").value;
        if (nombre == 0)
        {
            error_string+="<p>El campo nombre no puede estar vacío</p>";
            errors++;
            
        } //nombre
    
    
        if (paterno == 0)
        {
            error_string+="<p>El campo paterno no puede estar vacío</p>";
            errors++;
            
        } //paterno
    
    
        if (materno == 0)
        {
           error_string+="<p>El campo materno no puede estar vacío</p>";
        
            errors++;
            
        } //materno


        

       

       var genero=document.getElementById("genero").value;

        if (genero == 0)
        {
            error_string+="<p>Selecciona una opción en el campo género</p>";
            errors++;
            
        } //genero


        
       
        
        
        
        

    
       var fecha_nacimiento=document.getElementById("fecha_nacimiento").value;
       var edad_califica=document.getElementById("edad_califica").value;

       if (edad_califica == 0 ||edad_califica == '0')
        {
            error_string+="<p>"+"Fecha de nacimiento fuera del rango permitido"+"</p>";
            
            errors++;
            
        } //materno

       var sobrenombre=document.getElementById("sobrenombre").value;
       if(sobrenombre==""){
        errors++;
        error_string+="<p>El campo sobrenombre no puede estar vacío</p>";

       }


    
       var idusuario=document.getElementById("idusuario").value;
       var area=document.getElementById("area").value;
       var distrito=document.getElementById("distrito").value;
       
       

       var lugar_nacimiento=document.getElementById("lugar_nacimiento").value;
       if(lugar_nacimiento==""){
        errors++;
        error_string+="<p>El campo Lugar de nacimiento no puede estar vacío</p>";

       }
       var lugar_residencia=document.getElementById("lugar_residencia").value;
       if(lugar_residencia==""){
        errors++;
        error_string+="<p>El campo Lugar de residencia no puede estar vacío</p>";

       }

       var resido_cdmx=+document.getElementById("resido_cdmx").checked;
       var soyoriundo=+document.getElementById("soyoriundo").checked;
       var soyoriginario=+document.getElementById("soyoriginario").checked;
       var suma=resido_cdmx+soyoriundo+soyoriginario;
       if(suma==0){
        errors++;
        error_string+="<p>Debes seleccionar al menos uno de los checkbox de Resido en la Ciudad de México, o Soy oriundo de la Ciudad de México o Soy hija/o de madre o padre originario de la Ciudad de México</p>";

       }

       var tel1=document.getElementById("tel1").value;
       if(isNaN(tel1)||tel1==""){
        errors++;
        error_string+="<p>El teléfono local debe contener números únicamente</p>";

       }

       var tel2=document.getElementById("tel2").value;
       if(isNaN(tel2)||tel2==""){
        errors++;
        error_string+="<p>El teléfono celular debe contener números únicamente</p>";

       }


       var correo=document.getElementById("correo").value;
       if (correo == 0)
        {
            error_string+="<p>"+"El campo correo no debe estar vacío"+"</p>";
            errors++;
            //$("#correo").focus();
            
        }//correo
        
        if (/^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,4})$/.test(correo)){
            //alert("La dirección de email es correcta.");
        } else {
            error_string+="<p>"+"La dirección de email es incorrecta."+"</p>";
            errors++;
            

        }




       var correo_tutor=document.getElementById("correo_tutor").value;
       var edad=document.getElementById("edad").value;
       //alert(correo_tutor);

       if(edad<=17){

            if(correo_tutor==""){
                 errors++;
                 error_string+="<p>"+"La dirección de correo electrónico del padre o tutor no puede estar vacía"+"</p>";
            }

            if (/^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,4})$/.test(correo_tutor)){
                //alert("La dirección de email es correcta.");
            }else{
                error_string+="<p>"+"La dirección de correo electrónico del padre o tutor es incorrecta."+"</p>";
                errors++;
                

            }


       }

       if(correo!=""){

          

          //var correorepetido =evaluarCorreoRepetido(correo);
          //document.getElementById('correo_repetido').value;

          /*var correorepetido=document.getElementById('correo_repetido').value;

          if(correorepetido==0||correorepetido=='0'){

            alert(correorepetido+"/ zero");

          }else{
              error_string+="<p>"+"El correo que utilizaste ya está registrado para otro usuario"+"</p>";
              errors++;

          }*/
      }


      

        if(errors>0){

           // alert(document.getElementById('div_errors').innerHTML);
            //document.getElementById("div_errors").innerHTML="xxxxxxxxx";
            document.getElementById('div_errors').innerHTML='<div class="alert alert-warning">'+error_string+'</div>';
            //document.getElementById("btn_guardar").disabled=false;
        


        }else{

            document.getElementById('div_errors').innerHTML='';
            


            $("#menu1").removeClass("active");

            $("#navmenu2").removeClass("disabled");
            $("#menu2").addClass("active");

        }



}

function evaluarCorreoRepetido(){

  var datos="mail="+document.getElementById('correo').value;

  //var repetido="x";
  

  var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //repetido= this.responseText;
                document.getElementById('correo_repetido').innerHTML=this.responseText;
               
                //alert("evaluar");


              
                



            }
        };
    
    xmlhttp.open("POST", "evaluarcorreorepetido.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8"); 
    xmlhttp.send(datos);
     //return repetido;

    

      


}


function guardarparticipantedistrito(){

         errors=0;
         error_string="";
   
      var nombre=document.getElementById("nombre").value;
    
       var paterno=document.getElementById("paterno").value;
    
       var materno=document.getElementById("materno").value;
        if (nombre == 0)
        {
            error_string+="<p>El campo nombre no puede estar vacío</p>";
            errors++;
            
        } //nombre
    
    
        if (paterno == 0)
        {
            error_string+="<p>El campo paterno no puede estar vacío</p>";
            errors++;
            
        } //paterno
    
    
        if (materno == 0)
        {
           error_string+="<p>El campo materno no puede estar vacío</p>";
        
            errors++;
            
        } //materno


        

       

       var genero=document.getElementById("genero").value;

        if (genero == 0)
        {
            error_string+="<p>Selecciona una opción en el campo género</p>";
            errors++;
            
        } //genero


        
       
        
        
        
        

    
       var fecha_nacimiento=document.getElementById("fecha_nacimiento").value;
       var edad_califica=document.getElementById("edad_califica").value;

       if (edad_califica == 0 ||edad_califica == '0')
        {
            error_string+="<p>"+"Fecha de nacimiento fuera del rango permitido"+"</p>";
            
            errors++;
            
        } //materno

       var sobrenombre=document.getElementById("sobrenombre").value;
       if(sobrenombre==""){
        errors++;
        error_string+="<p>El campo sobrenombre no puede estar vacío</p>";

       }


    
       var idusuario=document.getElementById("idusuario").value;
       var area=document.getElementById("area").value;
       var distrito=document.getElementById("distrito").value;
       
       

       var lugar_nacimiento=document.getElementById("lugar_nacimiento").value;
       if(lugar_nacimiento==""){
        errors++;
        error_string+="<p>El campo Lugar de nacimiento no puede estar vacío</p>";

       }
       var lugar_residencia=document.getElementById("lugar_residencia").value;
       if(lugar_residencia==""){
        errors++;
        error_string+="<p>El campo Lugar de residencia no puede estar vacío</p>";

       }

       var resido_cdmx=+document.getElementById("resido_cdmx").checked;
       var soyoriundo=+document.getElementById("soyoriundo").checked;
       var soyoriginario=+document.getElementById("soyoriginario").checked;
       var suma=resido_cdmx+soyoriundo+soyoriginario;
       if(suma==0){
        errors++;
        error_string+="<p>Debes seleccionar al menos uno de los checkbox de Resido en la Ciudad de México, o Soy oriundo de la Ciudad de México o Soy hija/o de madre o padre originario de la Ciudad de México</p>";

       }

       var tel1=document.getElementById("tel1").value;
       if(isNaN(tel1)||tel1==""){
        errors++;
        error_string+="<p>El teléfono local debe contener números únicamente</p>";

       }

       var tel2=document.getElementById("tel2").value;
       if(isNaN(tel2)||tel2==""){
        errors++;
        error_string+="<p>El teléfono celular debe contener números únicamente</p>";

       }


       var correo=document.getElementById("correo").value;
       if (correo == 0)
        {
            error_string+="<p>"+"El campo correo no debe estar vacío"+"</p>";
            errors++;
            //$("#correo").focus();
            
        }//correo
        
        if (/^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,4})$/.test(correo)){
            //alert("La dirección de email es correcta.");
        } else {
            error_string+="<p>"+"La dirección de email es incorrecta."+"</p>";
            errors++;
            

        }




       var correo_tutor=document.getElementById("correo_tutor").value;
       var edad=document.getElementById("edad").value;
       //alert(correo_tutor);

       if(edad<=17){

            if(correo_tutor==""){
                 errors++;
                 error_string+="<p>"+"La dirección de correo electrónico del padre o tutor no puede estar vacía"+"</p>";
            }

            if (/^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,4})$/.test(correo_tutor)){
                //alert("La dirección de email es correcta.");
            }else{
                error_string+="<p>"+"La dirección de correo electrónico del padre o tutor es incorrecta."+"</p>";
                errors++;
                

            }


       }

       //////////////
        var boceto= +document.getElementById("boceto").checked;
        if(boceto==0){

            error_string+="<p>"+"Falta presentar el documento correspondiente al boceto "+"</p>";
            errors++;

        }
        var identificacion= +document.getElementById("identificacion").checked;
        if(identificacion==0){

            error_string+="<p>"+"Falta presentar el documento correspondiente a la identificacion "+"</p>";
            errors++;

        }
        var declaracion= +document.getElementById("declaracion").checked;
        if(declaracion==0){

            error_string+="<p>"+"Falta presentar el documento correspondiente a la declaracion "+"</p>";
            errors++;

        }
        var manifestacion= +document.getElementById("manifestacion").checked;
        if(manifestacion==0){

            error_string+="<p>"+"Falta presentar el documento correspondiente a la manifestacion "+"</p>";
            errors++;

        }
        var carta= +document.getElementById("carta").checked;
        if(carta==0){

            error_string+="<p>"+"Falta presentar el documento correspondiente a la carta "+"</p>";
            errors++;

        }
        var formato= +document.getElementById("formato").checked;
        if(formato==0){

            error_string+="<p>"+"Falta presentar el documento correspondiente al formato "+"</p>";
            errors++;

        }

       
       

       ////////////




      

        if(errors>0){

           // alert(document.getElementById('div_errors').innerHTML);
            //document.getElementById("div_errors").innerHTML="xxxxxxxxx";
            document.getElementById('div_errors').innerHTML='<div class="alert alert-warning">'+error_string+'</div>';
            document.getElementById("btn_guardar").disabled=false;
            return false;


        }

       
        
    
       
        

    
        
               
    var datos="action=insert"+"&nombre="+nombre+"&paterno="+paterno+"&materno="+materno+"&sobrenombre="+sobrenombre+"&genero="+genero;
    datos+="&fecha_nacimiento="+fecha_nacimiento+"&idusuario="+idusuario+"&area="+area;
    datos+="&lugar_nacimiento="+lugar_nacimiento+"&lugar_residencia="+lugar_residencia+"&resido_cdmx="+resido_cdmx;
    datos+="&soyoriundo="+soyoriundo+"&soyoriginario="+soyoriginario+"&tel1="+tel1+"&tel2="+tel2+"&correo_tutor="+correo_tutor+"&correo="+correo;
    datos+="&distrito="+distrito;
    datos+="&boceto="+boceto+"&identificacion="+identificacion+"&declaracion="+declaracion+"&manifestacion="+manifestacion+"&carta="+carta+"&formato="+formato;
    
    //document.getElementById("menu1").innerHTML = datos;
    //alert(datos);
    var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("div_registro").innerHTML = this.responseText;
                document.getElementById('div_errors').innerHTML='';
                



            }
        };
    
    xmlhttp.open("POST", "guardarparticipantedistrito.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8"); 
    xmlhttp.send(datos);

}







/*function rec_con(){

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("container").innerHTML = this.responseText;


            }
        };


        
        xmlhttp.open("POST", "rec_con.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8"); 
        

       var user=document.getElementById("user").value;
       var correo=document.getElementById("correo").value;
       var pass1=document.getElementById("pass1").value;

    
    
        if (user == 0)
        //alert("Hola!!");
        {
            alert("El campo usuario no debe estar vacío!!");
            $("#user").focus();
            return false;
        }//user
        
        if (correo == 0)
        {
            alert("El campo correo no debe estar vacío!!");
            $("#correo").focus();
            return false;
        }//correo

        if (/^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,4})$/.test(correo)){
            //alert("La dirección de email es correcta.");
        } else {
            alert("La dirección de email es incorrecta.");
                return false;
        }

        if (pass1 == 0)
        {
            alert("El campo contraseña no debe estar vacío!!");
            $("#pass1").focus();
            return false;
        }//pass1
        
                    //alert("hola!!");

               
        // var datos="action=update&user="+user+"&correo="+correo+"&pass1="+pass1;
      var datos="action=update"+"&user="+user+"&correo="+correo+"&pass1="+pass1;
      
                    //alert("hola!!");
           
       //var datos="action=insert"+"&nombre="+nombre+"&user="+user+"&pass1="+"&area="+area+"&correo="+correo;

        xmlhttp.send(datos);
  
        alert ("Contraseña actualiza correctamente!!");
}*/




function validar(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    patron =/[A-Za-z\s]/; // 4
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
}

function validar2(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    patron =/[A-Za-z\d]/; // 4
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
}






function fnUpload(id,index){

          // alert("suuub");
            

            //document.getElementById("upload-button").innerHTML = 'Uploading...';

        //alert("file-select-"+index);

         var files =  document.getElementById("file-select-"+index).files[0];

         document.getElementById("file-select-"+index).value="";
   
         //var filesQueja = document.getElementById("file-quejaini")
         var diverrormsg_="div_errors";

            if(files!=undefined){

                var vsize=files.size;

                var servermaxsize=4000000;//document.getElementById("maxsize_frm").value;

                var maxsize_mb=((servermaxsize/1000)/1000).toFixed(1);


                if(vsize>servermaxsize){
                     //document.getElementById('upload-button').disabled=false;
                      $("#"+diverrormsg_).html("<div class='alert alert-warning'>El archivo excede el tamaño permitido: "+maxsize_mb+" MB <button type='button' class='close' data-dismiss='alert'>&times;</button></div>");

                    return false;
                }

                


            }


            
            

            

            
            var formData = new FormData();
           

            formData.append('file-select',files);
            formData.append('idusuario',id);     
            formData.append('index',index); 
            
            var textloader='<div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div>';
            document.getElementById("row-"+index).innerHTML = textloader;
/*
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                     fnUpdateRow(id,index);
                     document.getElementById(diverrormsg_).innerHTML = this.responseText;
                     
                    



                }
            };
    
            xmlhttp.open("POST", "upload.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8"); 
            xmlhttp.send(formData);
            
*/



         var xhr = new XMLHttpRequest();

            xhr.open('POST', 'upload.php', true);


            xhr.onload = function () {
              if (xhr.status === 200) {
                // File(s) uploaded.
                //document.getElementById("upload-button").innerHTML = 'Uploaded!';

                //document.getElementById(divfileid).innerHTML = this.responseText;
                
                document.getElementById(diverrormsg_).innerHTML = this.responseText;
                fnUpdateRow(id,index);
                fnUpdateMensaje(id);

              } else {
                //alert('An error occurred!');
              }
            };

            xhr.send(formData);
            /**/
            


}

function fnUpdateRow(id,index){
  var divrow="row-"+index;

  var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //document.getElementById('div_errors').innerHTML = this.responseText;
                document.getElementById(divrow).innerHTML = this.responseText;
                //$('#select_colonia').append = this.responseText;
              
            }
        };

        //alert(usuario+" / "+convocatoria);

        
        var parametros="idusuario="+id+"&index="+index;
        xmlhttp.open("POST", "updaterow.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        
        xmlhttp.send(parametros);
}

function fnUpdateMensaje(id){
  

  var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //document.getElementById('div_errors').innerHTML = this.responseText;
                document.getElementById("mensajeadjuntos").innerHTML = this.responseText;
                //$('#select_colonia').append = this.responseText;
              
            }
        };

        //alert(usuario+" / "+convocatoria);

        
        var parametros="idusuario="+id;
        xmlhttp.open("POST", "mensajeadjuntos.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        
        xmlhttp.send(parametros);
}

function fnEdad(){

        var fecha_nacimiento=document.getElementById("fecha_nacimiento").value;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //document.getElementById('div_errors').innerHTML = this.responseText;

                var resultado=JSON.parse(this.responseText);
               
                document.getElementById("erroredad").innerHTML = resultado.mensaje;
                document.getElementById("edad_califica").value=resultado.califica;
                document.getElementById("edad").value=resultado.edad;
               
                //$('#select_colonia').append = this.responseText;
              
            }
        };

        //alert(usuario+" / "+convocatoria);

        
        var parametros="fecha_nacimiento="+fecha_nacimiento;
        xmlhttp.open("POST", "calculoedad.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        
        xmlhttp.send(parametros);

        



}

function fnReenviarCorreo(id){

        var correo="";// document.getElementById("correo").value;

        
        //var correo="x";

        var myid=id;
       

        if(myid=='0'){
             
            correo=document.getElementById("correo").value;

        }else{

            correo="";

        }

        var textloader='<div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div>';
        document.getElementById("divcorreo").innerHTML = textloader;

        //alert(correo);


        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                
                document.getElementById("divcorreo").innerHTML = this.responseText;

                
               
                //$('#select_colonia').append = this.responseText;
              
            }
        };

        //alert(usuario+" / "+convocatoria);

        
        var parametros="id="+id+"&correo="+correo;
        xmlhttp.open("POST", "reenviarcorreo.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        
        xmlhttp.send(parametros);


}
        
    
////////////////////////////////////////////////////////////validación

 function fnRadioBusqueda(){
          var num=$("input[type='radio'][name='radio_busqueda']:checked").val()
 



           switch(num){
            case '1':  
            document.getElementById('select_nombre').disabled=false;
            document.getElementById('btn_nombre').disabled=false;


            document.getElementById('select_distrito').disabled=true;
             //document.getElementById('btn_distrito').disabled=true;

            document.getElementById('select_folio').disabled=true;
             document.getElementById('btn_folio').disabled=true;
            break;

            case '2':  
            document.getElementById('select_folio').disabled=false;
             document.getElementById('btn_folio').disabled=false;

            document.getElementById('select_nombre').disabled=true;
            document.getElementById('btn_nombre').disabled=true; 
            document.getElementById('select_distrito').disabled=true;
            //document.getElementById('btn_distrito').disabled=true;

            break;

            case '3':  
            document.getElementById('select_distrito').disabled=false;
            //document.getElementById('btn_distrito').disabled=false;

            document.getElementById('select_folio').disabled=true; 
            document.getElementById('btn_folio').disabled=true; 
            document.getElementById('select_nombre').disabled=true;
            document.getElementById('btn_nombre').disabled=true;
               // document.getElementById('select_colonia').disabled=true;
               break;
            
          }

 }

////    /////////////////////////

function fnBusquedaFolio(){

  //alert ("entro funcion folio");
  
  var val=document.getElementById('select_folio').value;

  var textloader='<div class="row"><div class="loader"></div></div>';
  document.getElementById('menu_').innerHTML = textloader; 

  var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
                    //document.getElementById('div_errors').innerHTML = this.responseText;
                    document.getElementById('menu_').innerHTML = this.responseText;
                    //$('#select_colonia').append = this.responseText;

        }
    };


        var parametros="accion=folio&val="+val;
        xmlhttp.open("POST", "validacionlistado.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

        xmlhttp.send(parametros);

}

/////////// funcion de busqueda para el nombre 
function fnBusquedaNombre(){

  //alert ("entro funcion Nombre");
  
  var val=document.getElementById('select_nombre').value;

  var textloader='<div class="row"><div class="loader"></div></div>';
  document.getElementById('menu_').innerHTML = textloader; 

  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
                //document.getElementById('div_errors').innerHTML = this.responseText;
                document.getElementById('menu_').innerHTML = this.responseText;
                //$('#select_colonia').append = this.responseText;

              }
            };


            var parametros="accion=nombre&val="+val;
            xmlhttp.open("POST", "validacionlistado.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

            xmlhttp.send(parametros);

          }

///////////distrito ////////////

function fnBusquedaDistrito(){

 // alert ("entro funcion disrito");
  
  var val=document.getElementById('select_distrito').value;

  var textloader='<div class="row"><div class="loader"></div></div>';
  document.getElementById('menu_').innerHTML = textloader; 

  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
                //document.getElementById('div_errors').innerHTML = this.responseText;
                document.getElementById('menu_').innerHTML = this.responseText;
                //$('#select_colonia').append = this.responseText;

              }
            };


            var parametros="accion=distrito&val="+val;
            xmlhttp.open("POST", "validacionlistado.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

            xmlhttp.send(parametros);

          }
function fnValidar(id){

  

  var textloader='<div class="row"><div class="loader"></div></div>';
  document.getElementById('menu_').innerHTML = textloader; 

  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById('menu_').innerHTML = this.responseText;
    }
  };

  var parametros="id="+id;
  xmlhttp.open("POST", "g_validaciondocumentos.php", true);
  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  xmlhttp.send(parametros);

}

function fnguardarvalidaciones(){

  

  var id= document.getElementById("id").value;
  var estatus_boceto = document.getElementById("select_estatus_boceto").value;
  var observa_boceto = document.getElementById("observa_boceto").value;
  
    
  var estatus_identifica = document.getElementById("select_estatus_identifica").value;
  var observa_identifica = document.getElementById("observa_identifica").value;
  
  var estatus_declara = document.getElementById("select_estatus_declara").value;
  var observa_declara = document.getElementById("observa_declara").value;
  
  var estatus_manifest = document.getElementById("select_estatus_manifest").value;
  var observa_manifest = document.getElementById("observa_manifest").value;
  
  var estatus_carta = document.getElementById("select_estatus_cesion").value;
  var observa_carta = document.getElementById("observa_cesion").value;
  
  var estatus_formato = document.getElementById("select_estatus_formato").value;
  var observa_formato = document.getElementById("observa_formato").value;
  
  //var cumple_requi = document.getElementById("cumple_requi").value;
  //var no_cumple_requi = document.getElementById("no_cumple_requi").value;
  var observa_requi = document.getElementById("observa_requi").value;
  
  errors=0;
/////////////////

  if(errors>0){

  
           document.getElementById('div_errors').innerHTML='<div class="alert alert-warning">'+error_string+'</div>';
            document.getElementById("btn_guardar").disabled=false;
            return false;

  }

    
  var datos="action=update"+"&id="+id+"&estatus_boceto="+estatus_boceto+"&observa_boceto="+observa_boceto+"&estatus_identifica="+estatus_identifica+"&observa_identifica="+observa_identifica+"&estatus_declara="+estatus_declara+"&observa_declara="+observa_declara+"&estatus_manifest="+estatus_manifest+"&observa_manifest="+observa_manifest+"&estatus_carta="+estatus_carta+"&observa_carta="+observa_carta+"&estatus_formato="+estatus_formato+"&observa_formato="+observa_formato+"&observa_requi="+observa_requi;

  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById('menu_').innerHTML = this.responseText;
    }
  };

  //var parametros="action=update&id="+id;
  xmlhttp.open("POST", "g_validaciondocumentos.php", true);
  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  xmlhttp.send(datos);

}
