<?php
  //header("Location: login.php");


?>

<!doctype html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
   
    <title> </title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/mycss.css" rel="stylesheet">

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!--<script src="js/holder.min.js"></script>-->
    <script src="js/funcionesajax.js"></script>
    <link rel="stylesheet" href="css/all.css">

    




  </head>

  <body class="">

    <?php
      include("header.php");
    ?>

    <div class="container" id="main_container">

      
      
      <div class="row justify-content-md-center">
      	<div class="col-sm-auto">

      		<!--<a href="login.php?concurso=grafiti"><button class="btn btn-primary btn-portada">Concurso de grafiti</button></a>-->

          <a href="../grafiti/login.php?concurso=grafiti" class="btn-portada"><img src="img/grafiti.png"> </a>

          
      	</div>
      	<div class="col-sm-auto">
      		<a href="../cuento/login.php?concurso=cuento" class="btn-portada"><img src="img/cuento.png"></a>
      		
      	</div>
      </div>

      <div class="row justify-content-md-center">
      	<div class="col-sm-auto">
      		<a href="../ensayo/login.php?concurso=ensayo" class="btn-portada"><img src="img/ensayo.png"> </a>
      		
      	</div>
      	<div class="col-sm-auto">
      	<a href="login.php?concurso=debate" class="btn-portada"><img src="img/debate.png"> </a>
      	</div>
      </div>

    
      
      
    </div>

    
    <?php
      include("footer.php");
    ?>
  </body>
</html>

 