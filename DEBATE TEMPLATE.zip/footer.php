<?php
//echo "<p>**footer**</p>";
?>

<div class="footer">
	<div >
		<p>Instituto Electoral de la Ciudad de México &copy; 2019</p>

		<p>Huizaches 25, Colonia Rancho los Colorines, Alcaldía Tlalpan,  C.P. 14386, Ciudad de  M&eacute;xico.  Conmutador: (55) 5483 3800</p>
	</div>


</div>