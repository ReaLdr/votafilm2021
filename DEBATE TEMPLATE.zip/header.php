<div class="header" >
	
		
			<div class="row">
				<div class="col-sm-5">
					<img src="img/ban-iecm.png"  class="img-responsive " id="imgheader1" style="max-width: 200px;">
				</div>
				<div class="col-sm-6">
					<img src="img/ban-logo-2.png"  class="img-responsive" id="imgheader2">
				</div>
			</div>
	
	
	
</div>